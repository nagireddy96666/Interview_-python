num=10
while num > 0:
    num=num-1
    if num==4:
        continue
    print num
