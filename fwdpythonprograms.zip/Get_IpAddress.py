import socket
a=socket.gethostname()
b=socket.gethostbyname(a)
print a,"is host Name"
print b,"is ip address Host"
