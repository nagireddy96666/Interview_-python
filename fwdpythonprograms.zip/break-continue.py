n=input("enter a num")
for i in range(1,n+1):
    if i==30:
        break
    elif i==25:
        continue
    print i
    
