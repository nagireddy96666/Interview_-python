a="hai this is reddy"
a1=a.split()

for i in range(len(a1)):
    if a1[i]=="reddy":
        a1[i]="king"


a=" ".join(a1)
print a





s="hai this is"
    
s1=s.replace("this","how are u")
print s1
