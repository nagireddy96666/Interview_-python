import os
items=os.listdir(".")
newlist=[]
for names in items:
    if names.endswith(".txt"):
        newlist.append(names)
print newlist
