a="hai this is"
s1=a[::]

print s1


s=[1,2,3,4]
m=s
print m
s.append(5)
print "m",m
print "s",s
