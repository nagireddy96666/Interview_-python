
def square():
    l=[1,2,3,4]
    j=[]
    for i in l:
        j.append(i*i)
    print j
square()    
