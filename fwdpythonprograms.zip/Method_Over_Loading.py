def add(x,y):
    return x+y
def add(x,y,z,a):
    return x+y+z+a
def add(m,n):
    return m-n
print add(10,5)
    
