a="ABCDEFGH"
b=[]
for i in reversed(a):
          "".join(b.append(i))
print b          
          
          
          
          
          
