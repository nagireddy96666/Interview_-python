# ex:1
def add(a,b):
    return a+b
print add(10,20)

# ex:2


def evenadd():
    e=[]
    o=[]
    for i in range(1,51):
        if i%2==0:
            e.append(i)
        else:
            o.append(i)
print e
print o

evenadd()
    
