n=input("enter a num")
if n==1:
    print n
elif n==2:
    print n
elif n==3:
    print n
else:
    print "enter valid num"
