n=input("enter a num")
if n<=0:
    print "enter a valid num"
else:
    for i in range(1,n+1):
        print i**i
