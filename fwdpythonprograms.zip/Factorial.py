n=int(raw_input("Enter Number::"))
def fact(n):
    f=1
    while n>=1:
        f=f*n
        n=n-1
    return f
print fact(n)
6
