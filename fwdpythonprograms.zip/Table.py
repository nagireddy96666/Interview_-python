i=18
for x in range(0,20):
	print i,"*",x,"=",i*x
