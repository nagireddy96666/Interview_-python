'''def occured():'''
from collections import Counter
l=['red','blue','red','green','red']
print Counter(l)
'''d={}
for i in l:
    if i in d:
        d[i]=d[i]+1
    else:
        d[i]=1
print d'''
'''l=['red','blue','red','green','red']'''
'''occured()'''
