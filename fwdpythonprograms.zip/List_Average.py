l=[1,2,3,4,5]
def add():
    a=sum(l)/len(l)
    return a
print add()
def length():
    b=len(l)
    return b
print length()
        
        
        
    
