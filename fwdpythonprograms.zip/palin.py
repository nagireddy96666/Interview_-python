a=[2,5,7,3]
b=[]
for i in a:
    if i<b:
    print i    
    
