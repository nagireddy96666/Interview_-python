a=100
if a==100:
    
    pass
    print a
else:
    print a

