n=input("enter a num")
a=1
while a<n:
    if a%2==0:
        print a
    a=a+1
