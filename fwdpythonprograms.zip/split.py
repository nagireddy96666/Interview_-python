a="hai this is reddy"
a2=a.split("s")
a1=a.split()
print a
