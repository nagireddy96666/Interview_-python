l=[]
pname=None
class ADD(object):
    def add_records(self):
        for pname in range(5):
            pname=raw_input("Enter person name::")
            l.append(pname)
        print l        
A=ADD()
A.add_records()

                    
                
