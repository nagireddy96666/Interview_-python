p=raw_input("enter number")
while not p.isdigit():
    print "Please Enter Integer Onley"
    p=raw_input("enter number")
else:
    print p
