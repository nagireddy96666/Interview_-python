a=[[1,2,3] for x in range(3)]
print a
