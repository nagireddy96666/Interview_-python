a=["hai","is","this"]
a2="-".join(a)
a1="".join(a)
print a1
print a2
